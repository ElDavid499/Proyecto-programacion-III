import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
autor:any = {nombres:'David', apellidos:'Perdomo Castillo',
  asignatura:'Programación 3', grupo:'Grupo 2', universidad:'Corhuila'}
}
