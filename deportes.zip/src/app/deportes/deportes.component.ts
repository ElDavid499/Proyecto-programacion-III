import { Component, OnInit } from '@angular/core';
import { Deporte } from './deporte';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-deportes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './deportes.component.html',
  styleUrls: ['./deportes.component.css']
})
export class DeportesComponent implements OnInit {
  deportes: Deporte[] = [
    {nombre: 'Futbol', jugadores_por_equipo: 11, duracion_del_partido: '90', popularidad_global: 'Alta', origen: 'Inglaterra'},
    {nombre: 'Baloncesto', jugadores_por_equipo: 5, duracion_del_partido: '48', popularidad_global: 'Alta', origen: 'Estados Unidos'},
    {nombre: 'Tenis', jugadores_por_equipo: 1, duracion_del_partido: 'Variable', popularidad_global: 'Alta', origen: 'Francia'},
  ];

  ngOnInit(): void {
  }
}
