export class Deporte {
    nombre: string;
    jugadores_por_equipo: number;
    duracion_del_partido: string;
    popularidad_global: string;
    origen: string;
}
